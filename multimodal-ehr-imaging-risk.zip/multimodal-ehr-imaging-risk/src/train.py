"""
Train the multimodal EHR + imaging fusion model.
"""

import sys
import json
import joblib
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from preprocessing import load_and_preprocess
from model import MultimodalRiskModel

RESULTS_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/results")
RESULTS_DIR.mkdir(exist_ok=True)

torch.manual_seed(42)
np.random.seed(42)


def train(epochs: int = 25, lr: float = 1e-3, batch_size: int = 64):
    data = load_and_preprocess()

    X_ehr_train = torch.tensor(data["X_ehr_train"])
    img_train = torch.tensor(data["img_train"])
    y_train = torch.tensor(data["y_train"])

    X_ehr_test = torch.tensor(data["X_ehr_test"])
    img_test = torch.tensor(data["img_test"])
    y_test = torch.tensor(data["y_test"])

    model = MultimodalRiskModel(ehr_input_dim=X_ehr_train.shape[1])
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    # Class-weighted loss: in a risk-prediction setting, a missed High Risk
    # case (false negative) is generally more costly than a false alarm, and
    # High Risk is the minority class in this dataset (~26%). Weighting the
    # loss inversely to class frequency is a standard, honest way to reflect
    # that asymmetry rather than optimizing for raw accuracy alone.
    class_counts = torch.bincount(y_train)
    class_weights = (class_counts.sum() / (len(class_counts) * class_counts)).float()
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    print(f"Class weights (Low Risk, High Risk): {class_weights.tolist()}")

    n_train = X_ehr_train.shape[0]
    history = {"train_loss": [], "train_acc": [], "test_acc": []}

    for epoch in range(epochs):
        model.train()
        perm = torch.randperm(n_train)
        epoch_loss, correct = 0.0, 0

        for i in range(0, n_train, batch_size):
            idx = perm[i : i + batch_size]
            xb_ehr, xb_img, yb = X_ehr_train[idx], img_train[idx], y_train[idx]

            optimizer.zero_grad()
            logits = model(xb_ehr, xb_img)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item() * xb_ehr.size(0)
            correct += (logits.argmax(dim=1) == yb).sum().item()

        train_loss = epoch_loss / n_train
        train_acc = correct / n_train

        model.eval()
        with torch.no_grad():
            test_logits = model(X_ehr_test, img_test)
            test_acc = (test_logits.argmax(dim=1) == y_test).float().mean().item()

        history["train_loss"].append(train_loss)
        history["train_acc"].append(train_acc)
        history["test_acc"].append(test_acc)

        if (epoch + 1) % 5 == 0 or epoch == 0:
            print(f"Epoch {epoch+1:2d}/{epochs} | loss={train_loss:.4f} | train_acc={train_acc:.4f} | test_acc={test_acc:.4f}")

    torch.save(model.state_dict(), RESULTS_DIR / "fusion_model.pt")
    joblib.dump(data["scaler"], RESULTS_DIR / "ehr_scaler.joblib")
    with open(RESULTS_DIR / "ehr_feature_names.json", "w") as f:
        json.dump(data["ehr_feature_names"], f)
    with open(RESULTS_DIR / "train_history.json", "w") as f:
        json.dump(history, f, indent=2)

    torch.save(
        {"X_ehr_test": X_ehr_test, "img_test": img_test, "y_test": y_test},
        RESULTS_DIR / "test_tensors.pt",
    )

    print(f"\nFinal fusion model test accuracy: {history['test_acc'][-1]:.4f}")
    return model, data


if __name__ == "__main__":
    train()
