"""
Preprocessing for the multimodal EHR + imaging risk prediction project.
Produces a stratified train/test split with paired, aligned EHR feature
tensors and image tensors (scaled to [0, 1], channel-first for PyTorch).
"""

import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

DATA_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/data")

EHR_FEATURES = [
    "age", "heart_rate", "resp_rate", "spo2", "temperature",
    "wbc_count", "crp", "comorbidity_score",
]


def load_and_preprocess(test_size: float = 0.25, random_state: int = 42):
    ehr_df = pd.read_csv(DATA_DIR / "ehr_records.csv")
    images = np.load(DATA_DIR / "images.npy")

    X_ehr = ehr_df[EHR_FEATURES].values.astype(np.float32)
    y = ehr_df["label"].values.astype(np.int64)

    idx = np.arange(len(ehr_df))
    idx_train, idx_test = train_test_split(
        idx, test_size=test_size, random_state=random_state, stratify=y
    )

    scaler = StandardScaler()
    X_ehr_train = scaler.fit_transform(X_ehr[idx_train]).astype(np.float32)
    X_ehr_test = scaler.transform(X_ehr[idx_test]).astype(np.float32)

    # Images: [0, 255] uint8 -> [0, 1] float32, add channel dim (N, 1, H, W)
    img_train = (images[idx_train].astype(np.float32) / 255.0)[:, None, :, :]
    img_test = (images[idx_test].astype(np.float32) / 255.0)[:, None, :, :]

    return {
        "X_ehr_train": X_ehr_train,
        "X_ehr_test": X_ehr_test,
        "img_train": img_train,
        "img_test": img_test,
        "y_train": y[idx_train],
        "y_test": y[idx_test],
        "ehr_feature_names": EHR_FEATURES,
        "scaler": scaler,
        "idx_train": idx_train,
        "idx_test": idx_test,
    }


if __name__ == "__main__":
    data = load_and_preprocess()
    print("EHR train:", data["X_ehr_train"].shape, "| EHR test:", data["X_ehr_test"].shape)
    print("Img train:", data["img_train"].shape, "| Img test:", data["img_test"].shape)
    print("Label balance (train):", np.bincount(data["y_train"]) / len(data["y_train"]))
