"""
Grad-CAM explainability for the imaging branch.

Computes class-activation heatmaps over the last convolutional layer
(conv4) of the ImagingBranch, using gradients of the fused model's output
with respect to those activations -- so the heatmap reflects what the
imaging branch is contributing to the FULL fusion model's decision, not
an isolated single-modality model.
"""

import sys
import torch
import torch.nn.functional as F
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from model import MultimodalRiskModel

RESULTS_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/results")

test_data = torch.load(RESULTS_DIR / "test_tensors.pt", weights_only=False)
X_ehr_test, img_test, y_test = test_data["X_ehr_test"], test_data["img_test"], test_data["y_test"]

model = MultimodalRiskModel(ehr_input_dim=X_ehr_test.shape[1])
model.load_state_dict(torch.load(RESULTS_DIR / "fusion_model.pt", weights_only=True))
model.eval()


def grad_cam(model, x_ehr_single, x_img_single, target_class: int):
    """
    x_ehr_single: (1, ehr_dim), x_img_single: (1, 1, H, W)
    Returns a (H, W) heatmap normalized to [0, 1].
    """
    x_img_single = x_img_single.clone().requires_grad_(True)
    logits = model(x_ehr_single, x_img_single, register_hook=True)
    score = logits[0, target_class]

    model.zero_grad()
    score.backward()

    gradients = model.img_branch._gradients  # (1, C, h, w)
    activations = model.img_branch._activations.detach()  # (1, C, h, w)

    weights = gradients.mean(dim=(2, 3), keepdim=True)  # global-average-pooled gradients
    cam = F.relu((weights * activations).sum(dim=1, keepdim=True))  # (1, 1, h, w)
    cam = F.interpolate(cam, size=x_img_single.shape[-2:], mode="bilinear", align_corners=False)
    cam = cam.squeeze().detach().numpy()

    cam = cam - cam.min()
    if cam.max() > 0:
        cam = cam / cam.max()
    return cam


with torch.no_grad():
    all_logits = model(X_ehr_test, img_test)
    all_probs = torch.softmax(all_logits, dim=1)

high_risk_confident_idx = [
    i for i in range(len(y_test))
    if y_test[i].item() == 1 and all_probs[i, 1].item() > 0.6
][:4]

fig, axes = plt.subplots(2, len(high_risk_confident_idx), figsize=(4 * len(high_risk_confident_idx), 8))

for col, idx in enumerate(high_risk_confident_idx):
    x_ehr_single = X_ehr_test[idx : idx + 1]
    x_img_single = img_test[idx : idx + 1]

    cam = grad_cam(model, x_ehr_single, x_img_single, target_class=1)
    original_img = x_img_single.squeeze().detach().numpy()

    axes[0, col].imshow(original_img, cmap="gray", vmin=0, vmax=1)
    axes[0, col].set_title(f"Input (idx={idx})\nP(High Risk)={all_probs[idx,1]:.2f}")
    axes[0, col].axis("off")

    axes[1, col].imshow(original_img, cmap="gray", vmin=0, vmax=1)
    axes[1, col].imshow(cam, cmap="jet", alpha=0.45)
    axes[1, col].set_title("Grad-CAM overlay")
    axes[1, col].axis("off")

plt.suptitle("Grad-CAM: imaging branch attention for correctly-classified High Risk cases", y=1.02)
plt.tight_layout()
plt.savefig(RESULTS_DIR / "gradcam_examples.png", dpi=150, bbox_inches="tight")
plt.close()
print("Saved gradcam_examples.png")
print(f"Examples used (test indices): {high_risk_confident_idx}")
