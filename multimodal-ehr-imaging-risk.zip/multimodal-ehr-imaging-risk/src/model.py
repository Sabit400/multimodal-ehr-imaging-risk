"""
Multimodal fusion architecture for EHR + imaging risk prediction.

Two branches, each producing a fixed-size embedding, concatenated and
passed through a small fusion classifier head:

  - EHR branch: MLP on structured tabular features
  - Imaging branch: small CNN on 64x64 grayscale images

Kept deliberately compact (this is a methodology demonstration, not a
large-scale imaging benchmark) so that training is fast and the Grad-CAM /
SHAP explainability layers remain easy to interpret and inspect.
"""

import torch
import torch.nn as nn


class EHRBranch(nn.Module):
    def __init__(self, input_dim: int, embed_dim: int = 16):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 32),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(32, embed_dim),
            nn.ReLU(),
        )

    def forward(self, x):
        return self.net(x)


class ImagingBranch(nn.Module):
    """
    Small CNN. Named layers (conv1..conv4) so Grad-CAM can hook the last
    convolutional layer by name for explainability.
    """

    def __init__(self, embed_dim: int = 16):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.conv3 = nn.Conv2d(16, 32, kernel_size=3, padding=1)
        self.conv4 = nn.Conv2d(32, 32, kernel_size=3, padding=1)  # Grad-CAM target layer
        self.pool = nn.MaxPool2d(2)
        self.relu = nn.ReLU()
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(32, embed_dim)

        self._activations = None
        self._gradients = None

    def activations_hook(self, grad):
        self._gradients = grad

    def forward(self, x, register_hook: bool = False):
        x = self.pool(self.relu(self.conv1(x)))   # 64 -> 32
        x = self.pool(self.relu(self.conv2(x)))   # 32 -> 16
        x = self.pool(self.relu(self.conv3(x)))   # 16 -> 8
        x = self.relu(self.conv4(x))              # 8 -> 8 (Grad-CAM target)

        self._activations = x
        if register_hook and x.requires_grad:
            x.register_hook(self.activations_hook)

        pooled = self.global_pool(x).flatten(1)
        embed = self.relu(self.fc(pooled))
        return embed


class MultimodalRiskModel(nn.Module):
    def __init__(self, ehr_input_dim: int, ehr_embed_dim: int = 16, img_embed_dim: int = 16, num_classes: int = 2):
        super().__init__()
        self.ehr_branch = EHRBranch(ehr_input_dim, ehr_embed_dim)
        self.img_branch = ImagingBranch(img_embed_dim)
        self.fusion = nn.Sequential(
            nn.Linear(ehr_embed_dim + img_embed_dim, 24),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(24, num_classes),
        )

    def forward(self, x_ehr, x_img, register_hook: bool = False):
        ehr_embed = self.ehr_branch(x_ehr)
        img_embed = self.img_branch(x_img, register_hook=register_hook)
        fused = torch.cat([ehr_embed, img_embed], dim=1)
        return self.fusion(fused)
