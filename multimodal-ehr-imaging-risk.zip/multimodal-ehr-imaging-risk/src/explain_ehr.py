"""
SHAP explainability for the EHR branch.

The fusion model is a PyTorch multimodal network, not a tree model, so we
use shap.GradientExplainer against the EHR input while holding a
representative background image batch fixed. This attributes each EHR
feature's contribution to the fused model's prediction, keeping the
imaging pathway active (not zeroed out), so the explanation reflects the
EHR branch's actual role inside the full fusion model rather than an
isolated single-modality surrogate.
"""

import sys
import json
import torch
import shap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from model import MultimodalRiskModel

RESULTS_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/results")

test_data = torch.load(RESULTS_DIR / "test_tensors.pt", weights_only=False)
X_ehr_test, img_test, y_test = test_data["X_ehr_test"], test_data["img_test"], test_data["y_test"]

with open(RESULTS_DIR / "ehr_feature_names.json") as f:
    feature_names = json.load(f)

model = MultimodalRiskModel(ehr_input_dim=X_ehr_test.shape[1])
model.load_state_dict(torch.load(RESULTS_DIR / "fusion_model.pt", weights_only=True))
model.eval()

# Fix a representative background image batch (mean image avoids biasing
# the explanation toward any single patient's imaging pattern).
background_img = img_test.mean(dim=0, keepdim=True)


class EHRWrapper(torch.nn.Module):
    """Wraps the fusion model so SHAP only perturbs the EHR input; the
    imaging input is held fixed at the background image for every sample,
    which isolates the EHR branch's marginal contribution."""

    def __init__(self, fusion_model, fixed_img):
        super().__init__()
        self.fusion_model = fusion_model
        self.fixed_img = fixed_img

    def forward(self, x_ehr):
        batch_img = self.fixed_img.expand(x_ehr.shape[0], -1, -1, -1)
        return self.fusion_model(x_ehr, batch_img)


wrapped_model = EHRWrapper(model, background_img)
wrapped_model.eval()

background_ehr = X_ehr_test[:100]
explain_sample = X_ehr_test[:300]

explainer = shap.GradientExplainer(wrapped_model, background_ehr)
shap_values = explainer.shap_values(explain_sample)

if isinstance(shap_values, list):
    shap_high_risk = shap_values[1]  # class index 1 = High Risk
else:
    shap_high_risk = shap_values[:, :, 1]

plt.figure()
shap.summary_plot(
    shap_high_risk,
    explain_sample.numpy(),
    feature_names=feature_names,
    show=False,
    plot_size=(8, 6),
)
plt.title("SHAP feature importance (EHR branch) — High Risk class")
plt.tight_layout()
plt.savefig(RESULTS_DIR / "shap_ehr_summary.png", dpi=150)
plt.close()
print("Saved shap_ehr_summary.png")

mean_abs_shap = np.abs(shap_high_risk).mean(axis=0)
importance = pd.Series(mean_abs_shap, index=feature_names).sort_values(ascending=False)
importance.to_json(RESULTS_DIR / "shap_ehr_importance.json")
print("\nTop EHR features by mean |SHAP value|:")
print(importance)
