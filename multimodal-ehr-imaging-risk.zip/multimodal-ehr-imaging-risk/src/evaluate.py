"""
Full evaluation metrics for the trained fusion model: accuracy, precision,
recall, F1, ROC-AUC, confusion matrix.
"""

import json
import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.metrics import (
    classification_report, confusion_matrix, roc_curve, auc,
)

import sys
sys.path.append(str(Path(__file__).parent))
from model import MultimodalRiskModel

RESULTS_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/results")

test_data = torch.load(RESULTS_DIR / "test_tensors.pt", weights_only=False)
X_ehr_test, img_test, y_test = test_data["X_ehr_test"], test_data["img_test"], test_data["y_test"]

model = MultimodalRiskModel(ehr_input_dim=X_ehr_test.shape[1])
model.load_state_dict(torch.load(RESULTS_DIR / "fusion_model.pt", weights_only=True))
model.eval()

with torch.no_grad():
    logits = model(X_ehr_test, img_test)
    probs = torch.softmax(logits, dim=1)[:, 1].numpy()
    preds = logits.argmax(dim=1).numpy()

y_true = y_test.numpy()
class_names = ["Low Risk", "High Risk"]

report = classification_report(y_true, preds, target_names=class_names, output_dict=True)
print(classification_report(y_true, preds, target_names=class_names))

fpr, tpr, _ = roc_curve(y_true, probs)
roc_auc = auc(fpr, tpr)
print(f"ROC-AUC: {roc_auc:.4f}")

with open(RESULTS_DIR / "metrics.json", "w") as f:
    json.dump({"classification_report": report, "roc_auc": roc_auc}, f, indent=2)

cm = confusion_matrix(y_true, preds)
plt.figure(figsize=(5, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
plt.xlabel("Predicted")
plt.ylabel("True")
plt.title("Confusion Matrix — Fusion Model")
plt.tight_layout()
plt.savefig(RESULTS_DIR / "confusion_matrix.png", dpi=150)
plt.close()

plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, label=f"Fusion model (AUC = {roc_auc:.3f})")
plt.plot([0, 1], [0, 1], "k--", label="Random (AUC = 0.500)")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve — Fusion Model")
plt.legend()
plt.tight_layout()
plt.savefig(RESULTS_DIR / "roc_curve.png", dpi=150)
plt.close()

print("Saved confusion_matrix.png and roc_curve.png")
