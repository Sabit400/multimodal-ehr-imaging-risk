"""
Ablation study: train EHR-only and Imaging-only models (same branch
architectures, no fusion) to quantify how much the multimodal fusion
actually contributes over either modality alone. This is the evidence
that justifies building a fusion architecture rather than asserting it.
"""

import sys
import json
import numpy as np
import torch
import torch.nn as nn
from pathlib import Path

sys.path.append(str(Path(__file__).parent))
from preprocessing import load_and_preprocess
from model import EHRBranch, ImagingBranch

RESULTS_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/results")

torch.manual_seed(42)
np.random.seed(42)


class EHROnlyModel(nn.Module):
    def __init__(self, input_dim, embed_dim=16, num_classes=2):
        super().__init__()
        self.branch = EHRBranch(input_dim, embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)

    def forward(self, x_ehr, x_img=None):
        return self.head(self.branch(x_ehr))


class ImagingOnlyModel(nn.Module):
    def __init__(self, embed_dim=16, num_classes=2):
        super().__init__()
        self.branch = ImagingBranch(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)

    def forward(self, x_ehr=None, x_img=None):
        return self.head(self.branch(x_img))


def train_ablation(model, X_ehr_train, img_train, y_train, X_ehr_test, img_test, y_test,
                    epochs=25, lr=1e-3, batch_size=64, use_ehr=True, use_img=True):
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    class_counts = torch.bincount(y_train)
    class_weights = (class_counts.sum() / (len(class_counts) * class_counts)).float()
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    n_train = y_train.shape[0]
    test_acc_history = []

    for epoch in range(epochs):
        model.train()
        perm = torch.randperm(n_train)
        for i in range(0, n_train, batch_size):
            idx = perm[i : i + batch_size]
            optimizer.zero_grad()
            logits = model(
                X_ehr_train[idx] if use_ehr else None,
                img_train[idx] if use_img else None,
            )
            loss = criterion(logits, y_train[idx])
            loss.backward()
            optimizer.step()

        model.eval()
        with torch.no_grad():
            test_logits = model(
                X_ehr_test if use_ehr else None,
                img_test if use_img else None,
            )
            test_acc = (test_logits.argmax(dim=1) == y_test).float().mean().item()
        test_acc_history.append(test_acc)

    return test_acc_history[-1], test_acc_history


def main():
    data = load_and_preprocess()
    X_ehr_train = torch.tensor(data["X_ehr_train"])
    img_train = torch.tensor(data["img_train"])
    y_train = torch.tensor(data["y_train"])
    X_ehr_test = torch.tensor(data["X_ehr_test"])
    img_test = torch.tensor(data["img_test"])
    y_test = torch.tensor(data["y_test"])

    print("Training EHR-only ablation...")
    ehr_model = EHROnlyModel(input_dim=X_ehr_train.shape[1])
    ehr_final_acc, ehr_history = train_ablation(
        ehr_model, X_ehr_train, img_train, y_train, X_ehr_test, img_test, y_test,
        use_ehr=True, use_img=False,
    )
    print(f"EHR-only final test accuracy: {ehr_final_acc:.4f}")

    print("\nTraining Imaging-only ablation...")
    img_model = ImagingOnlyModel()
    img_final_acc, img_history = train_ablation(
        img_model, X_ehr_train, img_train, y_train, X_ehr_test, img_test, y_test,
        use_ehr=False, use_img=True,
    )
    print(f"Imaging-only final test accuracy: {img_final_acc:.4f}")

    with open(RESULTS_DIR / "train_history.json") as f:
        fusion_history = json.load(f)
    fusion_final_acc = fusion_history["test_acc"][-1]

    ablation_results = {
        "ehr_only_accuracy": round(ehr_final_acc, 4),
        "imaging_only_accuracy": round(img_final_acc, 4),
        "fusion_accuracy": round(fusion_final_acc, 4),
        "fusion_gain_over_best_single_modality": round(
            fusion_final_acc - max(ehr_final_acc, img_final_acc), 4
        ),
    }
    with open(RESULTS_DIR / "ablation_results.json", "w") as f:
        json.dump(ablation_results, f, indent=2)

    print("\n--- Ablation summary ---")
    for k, v in ablation_results.items():
        print(f"{k}: {v}")


if __name__ == "__main__":
    main()
