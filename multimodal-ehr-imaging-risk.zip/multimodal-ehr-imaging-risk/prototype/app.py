"""
FastAPI prototype: submit an EHR record plus a base64-encoded 64x64
grayscale image, get back a risk prediction with BOTH explanations:
top contributing EHR features (gradient-based attribution) and a
Grad-CAM heatmap (base64 PNG) showing where the imaging branch focused.

Run with:
    uvicorn app:app --reload --port 8002
"""

import sys
import json
import base64
import io
import joblib
import torch
import torch.nn.functional as F
import numpy as np
from PIL import Image
from pathlib import Path
from fastapi import FastAPI
from pydantic import BaseModel, Field

sys.path.append(str(Path(__file__).parent.parent / "src"))
from model import MultimodalRiskModel

RESULTS_DIR = Path(__file__).parent.parent / "results"

app = FastAPI(
    title="Multimodal EHR + Imaging Risk Prediction API",
    description="Fused risk prediction with gradient-based EHR attribution and Grad-CAM imaging explanation.",
    version="1.0.0",
)

scaler = joblib.load(RESULTS_DIR / "ehr_scaler.joblib")
with open(RESULTS_DIR / "ehr_feature_names.json") as f:
    EHR_FEATURES = json.load(f)

model = MultimodalRiskModel(ehr_input_dim=len(EHR_FEATURES))
model.load_state_dict(torch.load(RESULTS_DIR / "fusion_model.pt", weights_only=True))
model.eval()

CLASS_NAMES = ["Low Risk", "High Risk"]


class RiskRequest(BaseModel):
    age: float
    heart_rate: float
    resp_rate: float
    spo2: float
    temperature: float
    wbc_count: float
    crp: float
    comorbidity_score: float
    image_base64: str = Field(..., description="Base64-encoded 64x64 grayscale PNG")


def _grad_cam(x_ehr: torch.Tensor, x_img: torch.Tensor, target_class: int):
    x_img = x_img.clone().requires_grad_(True)
    logits = model(x_ehr, x_img, register_hook=True)
    score = logits[0, target_class]
    model.zero_grad()
    score.backward()

    gradients = model.img_branch._gradients
    activations = model.img_branch._activations.detach()
    weights = gradients.mean(dim=(2, 3), keepdim=True)
    cam = F.relu((weights * activations).sum(dim=1, keepdim=True))
    cam = F.interpolate(cam, size=x_img.shape[-2:], mode="bilinear", align_corners=False)
    cam = cam.squeeze().detach().numpy()
    cam = cam - cam.min()
    if cam.max() > 0:
        cam = cam / cam.max()
    return cam


def _cam_to_base64_overlay(original_img: np.ndarray, cam: np.ndarray) -> str:
    import matplotlib.cm as cm

    heatmap = (cm.jet(cam)[:, :, :3] * 255).astype(np.uint8)
    base_rgb = np.stack([original_img * 255] * 3, axis=-1).astype(np.uint8)
    overlay = (0.55 * base_rgb + 0.45 * heatmap).astype(np.uint8)

    buf = io.BytesIO()
    Image.fromarray(overlay).save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("utf-8")


@app.get("/")
def root():
    return {
        "service": "Multimodal EHR + Imaging Risk Prediction API",
        "classes": CLASS_NAMES,
        "docs": "/docs",
    }


@app.post("/predict")
def predict(req: RiskRequest):
    row = req.model_dump()
    image_b64 = row.pop("image_base64")

    ehr_values = np.array([[row[f] for f in EHR_FEATURES]], dtype=np.float32)
    ehr_scaled = scaler.transform(ehr_values).astype(np.float32)
    x_ehr = torch.tensor(ehr_scaled)

    img_bytes = base64.b64decode(image_b64)
    img = Image.open(io.BytesIO(img_bytes)).convert("L").resize((64, 64))
    img_arr = np.array(img).astype(np.float32) / 255.0
    x_img = torch.tensor(img_arr)[None, None, :, :]

    with torch.no_grad():
        logits = model(x_ehr, x_img)
        probs = torch.softmax(logits, dim=1)[0]
    pred_idx = int(probs.argmax())

    cam = _grad_cam(x_ehr, x_img, target_class=pred_idx)
    overlay_b64 = _cam_to_base64_overlay(img_arr, cam)

    # Simple gradient-based EHR attribution (input x gradient), a lightweight
    # single-request alternative to the batch SHAP analysis in explain_ehr.py
    x_ehr_grad = x_ehr.clone().requires_grad_(True)
    logits_grad = model(x_ehr_grad, x_img)
    logits_grad[0, pred_idx].backward()
    ehr_attribution = (x_ehr_grad.grad[0] * x_ehr_grad[0]).detach().numpy()
    ehr_contributions = {
        f: round(float(v), 4) for f, v in zip(EHR_FEATURES, ehr_attribution)
    }

    return {
        "predicted_class": CLASS_NAMES[pred_idx],
        "probabilities": {cls: round(float(p), 4) for cls, p in zip(CLASS_NAMES, probs)},
        "ehr_feature_contributions": dict(
            sorted(ehr_contributions.items(), key=lambda kv: -abs(kv[1]))
        ),
        "gradcam_overlay_base64_png": overlay_b64,
    }


@app.get("/health")
def health():
    return {"status": "ok"}
