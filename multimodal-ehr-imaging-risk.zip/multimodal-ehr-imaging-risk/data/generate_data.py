"""
Synthetic Multimodal EHR + Imaging Dataset Generator
-------------------------------------------------------
Generates a paired dataset for a binary risk-prediction task (Low Risk /
High Risk for a modeled pulmonary risk indicator), consisting of:

  1. Structured EHR records: age, vitals (heart rate, respiratory rate,
     SpO2, temperature), lab values (WBC count, CRP), and comorbidity flags.
  2. Synthetic "imaging" proxies: 64x64 grayscale arrays with a
     structured radial density pattern whose intensity and texture
     correlate with the risk label — standing in for a chest X-ray-style
     opacity pattern.

This dataset is SYNTHETIC and the images are NOT real medical images of
any kind. Real credentialed medical imaging datasets (e.g., NIH
ChestX-ray14, MIMIC-CXR) require external access not available in this
project's development environment. The generator is designed so that the
EHR and imaging modalities are driven by two distinct (independently
drawn) latent risk components -- "systemic" and "structural" -- that are
combined to produce the label. This is what makes a fusion architecture
methodologically necessary to demonstrate: neither modality alone can
fully recover a label driven by both components. Results characterize the
multimodal fusion + explainability methodology, not real diagnostic
performance.

Author: Sabit Md Asad (project pipeline authored with Claude)
"""

import numpy as np
import pandas as pd
from pathlib import Path

RANDOM_SEED = 42
N_SAMPLES = 4000
IMG_SIZE = 64

OUT_DIR = Path("/home/claude/multimodal-ehr-imaging-risk/data")


def generate_ehr(n: int, rng: np.random.Generator, risk_latent: np.ndarray) -> pd.DataFrame:
    """risk_latent in [0, 1] drives correlated feature shifts."""
    age = np.clip(rng.normal(55 + 15 * risk_latent, 12), 18, 95)
    heart_rate = np.clip(rng.normal(78 + 25 * risk_latent, 10), 45, 160)
    resp_rate = np.clip(rng.normal(16 + 8 * risk_latent, 3), 10, 40)
    spo2 = np.clip(rng.normal(97 - 8 * risk_latent, 2), 70, 100)
    temperature = np.clip(rng.normal(37.0 + 1.2 * risk_latent, 0.6), 35, 41)
    wbc_count = np.clip(rng.normal(7.5 + 6 * risk_latent, 2.5), 2, 30)  # x10^9/L
    crp = np.clip(rng.exponential(5 + 40 * risk_latent), 0, 300)  # mg/L
    comorbidity_score = np.clip(rng.poisson(0.5 + 2.5 * risk_latent), 0, 8)

    return pd.DataFrame(
        {
            "age": age,
            "heart_rate": heart_rate,
            "resp_rate": resp_rate,
            "spo2": spo2,
            "temperature": temperature,
            "wbc_count": wbc_count,
            "crp": crp,
            "comorbidity_score": comorbidity_score,
        }
    )


def generate_image(rng: np.random.Generator, risk_latent: float) -> np.ndarray:
    """
    Generates a 64x64 grayscale array with a radial base density plus
    risk-correlated 'opacity blobs' (higher count/intensity/spread for
    higher risk_latent) and independent noise, so the image carries partial,
    imperfect signal about risk_latent -- not a deterministic giveaway.
    """
    y, x = np.mgrid[0:IMG_SIZE, 0:IMG_SIZE]
    cx, cy = IMG_SIZE / 2, IMG_SIZE / 2
    radial = np.sqrt((x - cx) ** 2 + (y - cy) ** 2)
    base = 0.5 - 0.35 * (radial / radial.max())  # lung-field-like radial falloff

    img = base.copy()

    n_blobs = rng.poisson(1 + 4 * risk_latent)
    for _ in range(n_blobs):
        bx, by = rng.uniform(10, IMG_SIZE - 10, size=2)
        sigma = rng.uniform(3, 6 + 5 * risk_latent)
        intensity = rng.uniform(0.15, 0.25 + 0.35 * risk_latent)
        blob = intensity * np.exp(-(((x - bx) ** 2 + (y - by) ** 2) / (2 * sigma**2)))
        img += blob

    img += rng.normal(0, 0.06, size=img.shape)  # independent sensor-style noise
    img = np.clip(img, 0, 1)
    return (img * 255).astype(np.uint8)


def generate_dataset(n_samples: int = N_SAMPLES, seed: int = RANDOM_SEED):
    rng = np.random.default_rng(seed)

    # Two partially independent latent risk components: a "systemic/metabolic"
    # component that drives the EHR modality, and a "structural/pulmonary"
    # component that drives the imaging modality. This is what makes fusion
    # methodologically meaningful to demonstrate: if a single shared latent
    # drove both modalities, either modality alone would already recover it
    # and fusion would add little (an earlier version of this generator had
    # exactly that flaw -- EHR alone reached ~98% of fusion accuracy). With
    # two distinct components, neither modality alone can fully recover the
    # combined label, so a fusion architecture has genuine complementary
    # signal to combine.
    risk_systemic = rng.beta(2, 3, n_samples)   # -> EHR features
    risk_structural = rng.beta(2, 3, n_samples)  # -> imaging features (independent draw)

    combined_risk = 0.5 * risk_systemic + 0.5 * risk_structural
    label_prob = np.clip(combined_risk + rng.normal(0, 0.08, n_samples), 0, 1)
    label = (label_prob > 0.5).astype(int)  # 0 = Low Risk, 1 = High Risk

    ehr_df = generate_ehr(n_samples, rng, risk_systemic)
    ehr_df["label"] = label
    ehr_df["patient_id"] = [f"P{i:05d}" for i in range(n_samples)]

    images = np.zeros((n_samples, IMG_SIZE, IMG_SIZE), dtype=np.uint8)
    for i in range(n_samples):
        images[i] = generate_image(rng, risk_structural[i])

    OUT_DIR.mkdir(exist_ok=True)
    ehr_df.to_csv(OUT_DIR / "ehr_records.csv", index=False)
    np.save(OUT_DIR / "images.npy", images)

    print(f"Generated {n_samples} paired EHR+imaging records")
    print("Label distribution:", pd.Series(label).value_counts(normalize=True).to_dict())
    print("EHR saved to:", OUT_DIR / "ehr_records.csv")
    print("Images saved to:", OUT_DIR / "images.npy", "shape:", images.shape)
    return ehr_df, images


if __name__ == "__main__":
    generate_dataset()
